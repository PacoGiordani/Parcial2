package main;

import main.Voo;

public class PassaigeiroComum extends Passageiro implements IPassageiro{
    
    public PassaigeiroComum(String nome, String cpf) {
        super(nome, cpf);
    }

    @Override
    public boolean reservaPassagem(Voo voo) {
        if(voo.verificaLugarPV(voo)){
            voo.aeronave.listaPassageirosComum.add(this);
            setNumPoltrona(voo.aeronave.listaPassageirosVip.size());
            return true;
        }else {
            return false;
        }
    
    }

} 

