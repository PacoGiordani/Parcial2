package main;

public class PassageiroVip extends Passageiro implements IPassageiro{

    public PassageiroVip(String nome, String cpf) {
        super(nome, cpf);
    }

    @Override
    public boolean reservaPassagem(Voo voo) {
        if(voo.verificaLugarPV(voo)){
            voo.aeronave.listaPassageirosComum.add(this);
            setNumPoltrona(voo.aeronave.listaPassageirosComum.size());
            return true;
        }else {
            return false;
        }
    }

   
    
    
}
