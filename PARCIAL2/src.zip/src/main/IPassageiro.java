package main;

import main.Voo;

public interface IPassageiro {
    boolean reservaPassagem(Voo voo);
    
}
