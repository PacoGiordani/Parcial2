package main;

public class Boeing727 extends Aeronave{
    private final int capacidade = 160;       

    @Override
    public int getCapacidade() {
        return capacidade;
    }
    
}
