package main;

public class Airbus330 extends Aeronave{
    private final int capacidade = 200;

    @Override
    public int getCapacidade() {
        return capacidade;
    } 
    
}