package main;

public class PassageiroPreferencial {
    //para futuras novas integrações
}
