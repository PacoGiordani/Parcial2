package main;

public class Tester {
    public static void main(String[] args) {
    Conexao c = new Conexao(); 
    Passageiro p1 = new PassageiroVip("Gilmar", "06542728910");
    Passageiro p2 = new PassageiroVip("Gilmar2", "06542728910");
    Aeronave aviao1 = new Airbus330();
    Aeronave aviao2 = new Boeing727();
//    ReservaPassagem reservaPassagem = new ReservaPassagem();
    Voo voo1 = new Voo(aviao1);
    Voo voo2 = new Voo(aviao2);
     
    
    
    
   
    
   
       
    
    
    } 
}
